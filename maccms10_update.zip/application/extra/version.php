<?php
return array (
    'name' => '苹果CMS',
    'copyright' => 'MacCMS.LA',
    'url' => '//www.maccms.la/',
    'code' => '2019.1000.1029',
    'license' => '免费版',
);
?>