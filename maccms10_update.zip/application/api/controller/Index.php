<?php
namespace app\api\controller;
use think\Controller;
use think\Cache;

class Index extends Base
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {

    }
}
